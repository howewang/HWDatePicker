//
//  HWDatePicker.m
//  pickerTEst
//
//  Created by Howe on 2017/6/16.
//  Copyright © 2017年 Howe. All rights reserved.
//

#import "HWDatePicker.h"
#define WINDOW_Width [[UIScreen mainScreen] bounds].size.width
#define WINDOW_Height [[UIScreen mainScreen] bounds].size.height
#define DATE_FORMAT_All @"yyyy-MM-dd HH:mm:ss"
#define DATE_FORMAT_NoSecond @"yyyy-MM-dd HH:mm"
#define TEXT_COLOR_NOOMEL [UIColor blackColor]
#define TEXT_COLOR_DISABLED [UIColor lightGrayColor]

static  NSInteger PickerMinYear = 1800;
static  NSInteger PickerMaxYear = 3000;
static const NSString *YEAR = @"YEAR";
static const NSString *MONTH = @"MONTH";
static const NSString *DAY = @"DAY";
static const NSString *HOUR = @"HOUR";
static const NSString *MINUTE = @"MINUTE";
static const NSString *SECOND = @"SECOND";


@interface HWDatePicker ()<UIPickerViewDelegate,UIPickerViewDataSource>
@property (strong , nonatomic) HWDatePickerDoneHnadler doneHandler;
@property (strong , nonatomic) HWDatePickerScrollCompentHandler scrollHandler;
@property (strong , nonatomic) HWDatePickerCancelHandler cancelHandler;
@property (strong , nonatomic) UIView *contentView;
@property (strong , nonatomic) UIPickerView *pickerView;
@property (strong , nonatomic) UIButton *cancelButton;
@property (strong , nonatomic) UIButton *doneButton;
@property (strong , nonatomic) NSMutableDictionary *valueDic;
@property (assign , nonatomic) HWDatePickerMode pickerMode;

@property (copy , nonatomic) NSString *currentYear;
@property (copy , nonatomic) NSString *currentMonth;
@property (copy , nonatomic) NSString *currentDay;
@property (copy , nonatomic) NSString *currentHour;
@property (copy , nonatomic) NSString *currentMinute;
@property (copy , nonatomic) NSString *currentSecond;

@end




@implementation HWDatePicker


-(instancetype)initWithPikcerMode:(HWDatePickerMode)pickerMode scrollHandlder:(HWDatePickerScrollCompentHandler)scrollHandler doneHandler:(HWDatePickerDoneHnadler)doneHandler cancelHandler:(HWDatePickerCancelHandler)cancelHandler{
    self = [super initWithFrame:CGRectMake(0, WINDOW_Height - 250, WINDOW_Width, 250)];
    if (self) {
        _scrollHandler = scrollHandler;
        _doneHandler = doneHandler;
        _cancelHandler = cancelHandler;
        //最小时间 1800-01-01 00：00：00
        _minDate = [self dateWithString:@"1800-01-01 00:00" format:DATE_FORMAT_NoSecond];
        //最大时间 3000-12-31 23：59：59
        _maxDate = [self dateWithString:@"3000-12-31 23:59" format:DATE_FORMAT_NoSecond];
        //初始化默认展示时间为当前时间
        _defineShowDate = [NSDate date];
        [self initDataWithPickerMode:pickerMode];
        [self initView];
    }
    return self;
}

- (void)initDataWithPickerMode:(HWDatePickerMode)pickerMode{
    self.valueDic = [NSMutableDictionary dictionaryWithCapacity:1];
    self.pickerMode = pickerMode;
}

- (NSArray *)getDataArrayWithMinValue:(NSInteger)min maxValue:(NSInteger)max{
    NSMutableArray *array = [NSMutableArray arrayWithCapacity:1];
    for (NSInteger i = min; i<= max; i++) {
        [array addObject:[NSString stringWithFormat:@"%ld",i]];
    }
    return array;
}

- (NSInteger)getMonthDaysWithMonth:(NSInteger)month year:(NSInteger)year{
    switch (month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            return 31;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            return 30;
        case 2:
            if ([self isBissextile:year]) {
                return 29;
            }else{
                return 28;
            }
        default:
            break;
    }
    return 0;
}
//根据制定格式将时间字符串转化为nadate
- (NSDate *)dateWithString:(NSString *)dateString format:(NSString *)format{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:format];
    return [formatter dateFromString:dateString];
}
//根据制定格式将时间转化为整形
- (NSString *)dateNumberWithDate:(NSDate *)date format:(NSString *)format{
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:format];
    NSString *string = [formatter stringFromDate:date];
    return string;
}
- (BOOL)isBissextile:(NSInteger)year{
    return year%4 == 0?YES:NO;
}

-(void)setDefineShowDate:(NSDate *)defineShowDate{
    _defineShowDate = defineShowDate;
    //设置当前显示时间，翻转滚轴
    self.currentYear = [self dateNumberWithDate:defineShowDate format:@"yyyy"];
    self.currentMonth = [self dateNumberWithDate:defineShowDate format:@"MM"];
    self.currentDay = [self dateNumberWithDate:defineShowDate format:@"dd"];
    self.currentHour = [self dateNumberWithDate:defineShowDate format:@"HH"];
    self.currentMinute = [self dateNumberWithDate:defineShowDate format:@"mm"];
    if (self.pickerMode == HWDatePickerAllIn) {
        self.currentSecond = [self dateNumberWithDate:defineShowDate format:@"ss"];
    }
    //手动翻转滚轴
    [self selectPickerWithDefDate];
}
//根据默认展示时间翻转滚轴
- (void)selectPickerWithDefDate
{
    
    [self.pickerView selectRow:([[self dateNumberWithDate:self.defineShowDate format:@"yyyy"] integerValue] - PickerMinYear) inComponent:0 animated:YES];
    [self.pickerView selectRow:([[self dateNumberWithDate:self.defineShowDate format:@"MM"] integerValue] - 1) inComponent:1 animated:YES];
    [self.pickerView selectRow:([[self dateNumberWithDate:self.defineShowDate format:@"dd"] integerValue] - 1) inComponent:2 animated:YES];
    [self.pickerView selectRow:[[self dateNumberWithDate:self.defineShowDate format:@"HH"] integerValue] inComponent:3 animated:YES];
    [self.pickerView selectRow:[[self dateNumberWithDate:self.defineShowDate format:@"mm"] integerValue] inComponent:4 animated:YES];
    if (self.pickerMode == HWDatePickerAllIn) {
        [self.pickerView selectRow:[[self dateNumberWithDate:self.defineShowDate format:@"ss"] integerValue]inComponent:5 animated:YES];
    }
}
- (void)initView{
    self.contentView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)];
    [self addSubview:self.contentView];
    self.backgroundColor = [UIColor colorWithRed:219/255.0 green:219/255.0 blue:219/255.0 alpha:1];
    
    self.layer.shadowOffset = CGSizeMake(0, -3);
    self.layer.shadowColor = [[UIColor grayColor] CGColor];
    self.layer.shadowOpacity = 0.5;
    self.layer.shadowRadius = 2.0;
    
    self.pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 35, self.frame.size.width, self.frame.size.height-35)];
    self.pickerView.dataSource = self;
    self.pickerView.delegate = self;
    self.pickerView.showsSelectionIndicator = YES;
    self.pickerView.backgroundColor = [UIColor colorWithRed:240/255.0 green:240/255.0 blue:240/255.0 alpha:1];
    [self.contentView addSubview:self.pickerView];
    
    self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.cancelButton.frame = CGRectMake(5, 3, 40, 29);
    [self.cancelButton setTitle:@"取消" forState:UIControlStateNormal];
    [self.cancelButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    self.cancelButton.titleLabel.font = [UIFont boldSystemFontOfSize:15];
    [self.cancelButton addTarget:self action:@selector(cancelButtonFunc:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.cancelButton];
    
    self.doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.doneButton.frame = CGRectMake(self.frame.size.width-45, 3, 40, 29);
    [self.doneButton setTitle:@"确定" forState:UIControlStateNormal];
    [self.doneButton setTitleColor:[UIColor colorWithRed:24/255.0 green:112/255.0 blue:209/255.0 alpha:1] forState:UIControlStateNormal];
    self.doneButton.titleLabel.font = [UIFont boldSystemFontOfSize:15];
    [self.doneButton addTarget:self action:@selector(doneButtonFunc:) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:self.doneButton];
    
    float y = WINDOW_Height-self.frame.size.height/2;
    self.center = CGPointMake(self.frame.size.width/2, y);
}

-(void)cancelButtonFunc:(UIButton *)btn{
    float y = WINDOW_Height+self.frame.size.height/2;
    [UIView animateWithDuration:0.2 animations:^{
        self.center = CGPointMake(WINDOW_Width/2, y);
    }completion:^(BOOL finished) {
        
    }];
}

-(void)doneButtonFunc:(UIButton *)btn{
  
    if (self.doneHandler) {
        NSMutableString *dateString = [NSMutableString stringWithFormat:@"%@-%@-%@ %@:%@",self.currentYear,self.currentMonth,self.currentDay,self.currentHour,self.currentMinute];
        NSString *format = DATE_FORMAT_NoSecond;
        if (self.pickerMode == HWDatePickerAllIn) {
            [dateString appendFormat:@":%@",self.currentSecond];
            format = DATE_FORMAT_All;
        }
        //点击确定按钮，数据回调
        self.doneHandler([self dateWithString:dateString format:format], dateString, format);
    }
    
    float y = WINDOW_Height+self.frame.size.height/2;
    [UIView animateWithDuration:0.2 animations:^{
        self.center = CGPointMake(WINDOW_Width/2, y);
    }completion:^(BOOL finished) {
        
        
    }];
}
#pragma mark -- pickerDelegate
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return self.valueDic.allKeys.count;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    return array.count;
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    return [NSString stringWithFormat:@"%@%@",array[row],[self getTitleStringWithPickerViewComponent:component]];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    NSString *value = array[row];
    //保存每次选中的值
    //判断选中的值是否在最大最小之间，如果不是就回滚
    [self setCurrentTimeWithPickerComponent:component value:value];
    //判断每个月份有几天
    if ((component == 0 || component == 1) && self.currentMonth.length >0 && self.currentYear.length>0) {
        NSInteger dayCount = [self getMonthDaysWithMonth:[self.currentMonth integerValue] year:[self.currentYear integerValue]];
        NSArray *dayArray = [self getDataArrayWithMinValue:1 maxValue:dayCount];
        [self.valueDic setObject:dayArray forKey:DAY];
        
    }
    [pickerView reloadAllComponents];
    //滚轴滚动回调
    if (self.scrollHandler) {
        self.scrollHandler(component, value);
    }
    

}




-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 35;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    UILabel* pickerLabel = (UILabel*)view;
    if (!pickerLabel){
        pickerLabel = [[UILabel alloc] init];
        // Setup label properties - frame, font, colors etc
        //adjustsFontSizeToFitWidth property to YES
        pickerLabel.minimumScaleFactor = 0.0;
        pickerLabel.adjustsFontSizeToFitWidth = YES;
        [pickerLabel setTextAlignment:NSTextAlignmentCenter];
        [pickerLabel setBackgroundColor:[UIColor clearColor]];
        [pickerLabel setFont:[UIFont boldSystemFontOfSize:17]];
        //根据最大最小时间设置不可选时间的颜色
        pickerLabel.textColor = [self getColorForRow:row forComponent:component];
    }
    // Fill the label text here
    pickerLabel.text=[self pickerView:pickerView titleForRow:row forComponent:component];
    return pickerLabel;
}
- (UIColor *)getColorForRow:(NSInteger)row forComponent:(NSInteger)component
{
    BOOL isNor = YES;
    if (component == 0) {
        isNor = [self textColorWithYearWithRow:row component:component];
    }else if (component == 1){
        isNor = [self textColorWithMonthWithRow:row component:component];
    }
    else if (component == 2){
        isNor = [self textColorWithDayWithRow:row component:component];
    }
    else if (component == 3){
        isNor = [self textColorWithHourWithRow:row component:component];
    }
    else if (component == 4){
        isNor = [self textColorWithMinuteWithRow:row component:component];
    }
    else if (component == 5){
        isNor = [self textColorWithSecondithRow:row component:component];
    }
    return isNor?TEXT_COLOR_NOOMEL:TEXT_COLOR_DISABLED;
}
//获取年份的颜色
- (BOOL)textColorWithYearWithRow:(NSInteger)row component:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    NSString *value = array[row];
    if ([self compareDate:value format:@"yyyy"]) {
        return YES;
    }else{
        return NO;
    }
}
//获取月份的颜色
- (BOOL)textColorWithMonthWithRow:(NSInteger)row component:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    NSString *value = array[row];
    NSInteger currentYearNumber = [self.currentYear integerValue];
    NSInteger currentMonthNumber = [value integerValue];
    //比较年份
    if ([self compareDate:self.currentYear format:@"yyyy"]) {
        //年份在范围内,判断年份是否等于最小年份
        if (currentYearNumber == [[self dateNumberWithDate:self.minDate format:@"yyyy"] integerValue]) {
            //与最小年份的月份比较
            if (currentMonthNumber < [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]) {
                return NO;
            }
        }else if (currentYearNumber == [[self dateNumberWithDate:self.maxDate format:@"yyyy"] integerValue]){
            //与最大年份的月份比较
            if (currentMonthNumber > [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]) {
                return NO;
            }
        }
    }
    return YES;
}
- (BOOL)textColorWithDayWithRow:(NSInteger)row component:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    NSString *value = array[row];
    NSInteger currentYearNumber = [self.currentYear integerValue];
    NSInteger currentMonthNumber = [self.currentMonth integerValue];
    NSInteger currentDayNumber = [value integerValue];
    //比较年份
    if ([self compareDate:self.currentYear format:@"yyyy"]) {
        //年份在范围内,判断年份是否等于最小年份
        if (currentYearNumber == [[self dateNumberWithDate:self.minDate format:@"yyyy"] integerValue]) {
            //与最小年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]) {
                //月份与最小时间的月份相等
                if (currentDayNumber < [[self dateNumberWithDate:self.minDate format:@"dd"] integerValue]) {
                    return NO;
                }
            }else if (currentMonthNumber < [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]){
                return NO;
            }
        }else if (currentYearNumber == [[self dateNumberWithDate:self.maxDate format:@"yyyy"] integerValue]){
            //与最大年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]) {
                //月份与最大时间的月份相等
                if (currentDayNumber > [[self dateNumberWithDate:self.maxDate format:@"dd"] integerValue]) {
                    return NO;
                }
            }else if (currentMonthNumber > [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]){
                return NO;
            }
        }
    }
    return YES;
}
- (BOOL)textColorWithHourWithRow:(NSInteger)row component:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    NSString *value = array[row];
    NSInteger currentYearNumber = [self.currentYear integerValue];
    NSInteger currentMonthNumber = [self.currentMonth integerValue];
    NSInteger currentDayNumber = [self.currentDay integerValue];
    NSInteger currentHourNumber = [value integerValue];
    //比较年份
    if ([self compareDate:self.currentYear format:@"yyyy"]) {
        //年份在范围内,判断年份是否等于最小年份
        if (currentYearNumber == [[self dateNumberWithDate:self.minDate format:@"yyyy"] integerValue]) {
            //与最小年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]) {
                //月份与最小时间的月份相等
                if (currentDayNumber == [[self dateNumberWithDate:self.minDate format:@"dd"] integerValue]) {
                    //日与最小时间相等
                    if (currentHourNumber < [[self dateNumberWithDate:self.minDate format:@"HH"] integerValue]) {
                        return NO;
                    }
                }else if (currentDayNumber < [[self dateNumberWithDate:self.minDate format:@"Mdd"] integerValue]){
                    return NO;
                }
            }else if (currentMonthNumber < [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]){
                return NO;
            }
        }else if (currentYearNumber == [[self dateNumberWithDate:self.maxDate format:@"yyyy"] integerValue]){
            //与最大年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]) {
                //月份与最大时间的月份相等
                if (currentDayNumber == [[self dateNumberWithDate:self.maxDate format:@"dd"] integerValue]) {
                    //日与最大时间相等
                    if (currentHourNumber > [[self dateNumberWithDate:self.maxDate format:@"HH"] integerValue]) {
                        return NO;
                    }
                }else if (currentDayNumber > [[self dateNumberWithDate:self.maxDate format:@"dd"] integerValue]){
                    return NO;
                }
            }else if (currentMonthNumber > [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]){
                return NO;
            }
        }
    }
    return YES;
}
- (BOOL)textColorWithMinuteWithRow:(NSInteger)row component:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    NSString *value = array[row];
    NSInteger currentYearNumber = [self.currentYear integerValue];
    NSInteger currentMonthNumber = [self.currentMonth integerValue];
    NSInteger currentDayNumber = [self.currentDay integerValue];
    NSInteger currentHourNumber = [self.currentHour integerValue];
    NSInteger currentMinuteNumber = [value integerValue];
    //比较年份
    if ([self compareDate:self.currentYear format:@"yyyy"]) {
        //年份在范围内,判断年份是否等于最小年份
        if (currentYearNumber == [[self dateNumberWithDate:self.minDate format:@"yyyy"] integerValue]) {
            //与最小年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]) {
                //月份与最小时间的月份相等
                if (currentDayNumber == [[self dateNumberWithDate:self.minDate format:@"dd"] integerValue]) {
                    //日与最小时间相等
                    if (currentHourNumber == [[self dateNumberWithDate:self.minDate format:@"HH"] integerValue]) {
                        //时与最小时间相等
                        if (currentMinuteNumber < [[self dateNumberWithDate:self.minDate format:@"mm"] integerValue]) {
                            return NO;
                        }
                    }else if (currentHourNumber < [[self dateNumberWithDate:self.minDate format:@"HH"] integerValue]){
                        return NO;
                    }
                }else if (currentDayNumber < [[self dateNumberWithDate:self.minDate format:@"dd"] integerValue]){
                    return NO;
                }
            }else if (currentMonthNumber < [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]){
                return NO;
            }
        }else if (currentYearNumber == [[self dateNumberWithDate:self.maxDate format:@"yyyy"] integerValue]){
            //与最大年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]) {
                //月份与最大时间的月份相等
                if (currentDayNumber == [[self dateNumberWithDate:self.maxDate format:@"dd"] integerValue]) {
                    //日与最大时间相等
                    if (currentHourNumber == [[self dateNumberWithDate:self.maxDate format:@"HH"] integerValue]) {
                        //时与最大时间相等
                        if (currentMinuteNumber > [[self dateNumberWithDate:self.maxDate format:@"mm"] integerValue]) {
                            return NO;
                        }
                    }else if (currentHourNumber > [[self dateNumberWithDate:self.maxDate format:@"HH"] integerValue]){
                        return NO;
                    }
                }else if (currentDayNumber > [[self dateNumberWithDate:self.maxDate format:@"dd"] integerValue]){
                    return NO;
                }
            }else if (currentMonthNumber > [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]){
                return NO;
            }
        }
    }
    return YES;
}
- (BOOL)textColorWithSecondithRow:(NSInteger)row component:(NSInteger)component{
    NSArray *array = [self getDataArrayWithPickerViewComponent:component];
    NSString *value = array[row];
    NSInteger currentYearNumber = [self.currentYear integerValue];
    NSInteger currentMonthNumber = [self.currentMonth integerValue];
    NSInteger currentDayNumber = [self.currentDay integerValue];
    NSInteger currentHourNumber = [self.currentHour integerValue];
    NSInteger currentMinuteNumber = [self.currentMinute integerValue];
    NSInteger currentSecondNumber = [value integerValue];
    //比较年份
    if ([self compareDate:self.currentYear format:@"yyyy"]) {
        //年份在范围内,判断年份是否等于最小年份
        if (currentYearNumber == [[self dateNumberWithDate:self.minDate format:@"yyyy"] integerValue]) {
            //与最小年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]) {
                //月份与最小时间的月份相等
                if (currentDayNumber == [[self dateNumberWithDate:self.minDate format:@"dd"] integerValue]) {
                    //日与最小时间相等
                    if (currentHourNumber == [[self dateNumberWithDate:self.minDate format:@"HH"] integerValue]) {
                        //时与最小时间相等
                        if (currentMinuteNumber == [[self dateNumberWithDate:self.minDate format:@"mm"] integerValue]) {
                            //分与最小时间相等
                            if (currentSecondNumber < [[self dateNumberWithDate:self.minDate format:@"ss"] integerValue]) {
                                return NO;
                            }
                        }else if (currentMinuteNumber < [[self dateNumberWithDate:self.minDate format:@"mm"] integerValue]){
                            return NO;
                        }
                    }else if (currentHourNumber < [[self dateNumberWithDate:self.minDate format:@"HH"] integerValue]){
                        return NO;
                    }
                }else if (currentDayNumber < [[self dateNumberWithDate:self.minDate format:@"dd"] integerValue]){
                    return NO;
                }
            }else if (currentMonthNumber < [[self dateNumberWithDate:self.minDate format:@"MM"] integerValue]){
                return NO;
            }
        }else if (currentYearNumber == [[self dateNumberWithDate:self.maxDate format:@"yyyy"] integerValue]){
            //与最大年份的月份比较
            if (currentMonthNumber == [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]) {
                //月份与最大时间的月份相等
                if (currentDayNumber == [[self dateNumberWithDate:self.maxDate format:@"dd"] integerValue]) {
                    //日与最大时间相等
                    if (currentHourNumber == [[self dateNumberWithDate:self.maxDate format:@"HH"] integerValue]) {
                        //时与最大时间相等
                        if (currentMinuteNumber == [[self dateNumberWithDate:self.maxDate format:@"mm"] integerValue]) {
                            //分与最大时间相等
                            if (currentSecondNumber > [[self dateNumberWithDate:self.maxDate format:@"ss"] integerValue]) {
                                return NO;
                            }
                        }else if (currentMinuteNumber > [[self dateNumberWithDate:self.maxDate format:@"mm"] integerValue]){
                            return NO;
                        }
                    }else if (currentHourNumber > [[self dateNumberWithDate:self.maxDate format:@"HH"] integerValue]){
                        return NO;
                    }
                }else if (currentDayNumber > [[self dateNumberWithDate:self.maxDate format:@"dd"] integerValue]){
                    return NO;
                }
            }else if (currentMonthNumber > [[self dateNumberWithDate:self.maxDate format:@"MM"] integerValue]){
                return NO;
            }
        }
    }
    return YES;
}
- (BOOL)compareDate:(NSString *)date format:(NSString *)format{
    if ([date integerValue] < [[self dateNumberWithDate:self.minDate format:format] integerValue]||
        [date integerValue] > [[self dateNumberWithDate:self.maxDate format:format] integerValue]) {
        return NO;//不在设置的最大最小范围内
    }
    return YES;
}
//根据picker的component来获取对应时间轴的title
- (NSString *)getTitleStringWithPickerViewComponent:(NSInteger)component{
    switch (component) {
        case 0:
            return @"年";
            break;
        case 1:
            return @"月";
            break;
        case 2:
            return @"日";
            break;
        case 3:
            return @"时";
            break;
        case 4:
            return @"分";
            break;
        case 5:
            return @"秒";
            break;
            
        default:
            break;
    }
    return @"";
}
//根据picker的component来获取对应时间轴的数据数组
- (NSArray *)getDataArrayWithPickerViewComponent:(NSInteger)component{
    NSArray *array;
    switch (component) {
        case 0:
            array = [self.valueDic objectForKey:YEAR];
            break;
        case 1:
            array = [self.valueDic objectForKey:MONTH];
            break;
        case 2:
            array = [self.valueDic objectForKey:DAY];
            break;
        case 3:
            array = [self.valueDic objectForKey:HOUR];
            break;
        case 4:
            array = [self.valueDic objectForKey:MINUTE];
            break;
        case 5:
            array = [self.valueDic objectForKey:SECOND];
            break;
    
        default:
            break;
    }
    return array;
}

//设置pickerView的mode，从而设置显示几个时间轴
-(void)setPickerMode:(HWDatePickerMode)pickerMode{
    [self.valueDic removeAllObjects];
        [self.valueDic setObject:[self getDataArrayWithMinValue:PickerMinYear maxValue:PickerMaxYear] forKey:YEAR];
        [self.valueDic setObject:[self getDataArrayWithMinValue:1 maxValue:12] forKey:MONTH];
        [self.valueDic setObject:[self getDataArrayWithMinValue:1 maxValue:30] forKey:DAY];
        [self.valueDic setObject:[self getDataArrayWithMinValue:0 maxValue:23] forKey:HOUR];
        [self.valueDic setObject:[self getDataArrayWithMinValue:0 maxValue:59] forKey:MINUTE];
    if (pickerMode == HWDatePickerAllIn)
        [self.valueDic setObject:[self getDataArrayWithMinValue:0 maxValue:59] forKey:SECOND];
    _pickerMode = pickerMode;
}

//滚局滚轴滑动设置当前时间
- (void)setCurrentTimeWithPickerComponent:(NSInteger)component value:(NSString *)value{

    switch (component) {
        case 0:
            self.currentYear = value;
            break;
        case 1:
            self.currentMonth = value;
            break;
        case 2:
            self.currentDay = value;
            break;
        case 3:
            self.currentHour = value;
            break;
        case 4:
            self.currentMinute = value;
            break;
        case 5:
            self.currentSecond = value;
            break;
            
        default:
            break;
    }
    NSMutableString *dateString = [NSMutableString stringWithFormat:@"%@-%@-%@ %@:%@",self.currentYear,self.currentMonth,self.currentDay,self.currentHour,self.currentMinute];
    NSString *format = DATE_FORMAT_NoSecond;
    if (self.pickerMode == HWDatePickerAllIn) {
        [dateString appendFormat:@":%@",self.currentSecond];
        format = DATE_FORMAT_All;
    }
    NSDate *currentDate = [self dateWithString:dateString format:format];
    if ([currentDate compare:self.minDate] == NSOrderedAscending ) {
        self.defineShowDate = self.minDate;
    }else if ([currentDate compare:self.maxDate] == NSOrderedDescending){
        self.defineShowDate = self.maxDate;
    }
}
-(void)setMinDateString:(NSString *)minDateString{
    _minDateString = minDateString;
    self.minDate = [self dateWithString:minDateString format:self.pickerMode == HWDatePickerAllIn?DATE_FORMAT_All:DATE_FORMAT_NoSecond];
}
-(void)setMaxDateString:(NSString *)maxDateString{
    _maxDateString = maxDateString;
    self.maxDate = [self dateWithString:maxDateString format:self.pickerMode == HWDatePickerAllIn?DATE_FORMAT_All:DATE_FORMAT_NoSecond];
}
-(void)showPickerView
{
    
    float y = WINDOW_Height+self.frame.size.height/2;
    self.center = CGPointMake(self.frame.size.width/2, y);
    
    float y2 = WINDOW_Height-self.frame.size.height/2+5;
    [UIView animateWithDuration:0.2 animations:^{
        self.center = CGPointMake(self.frame.size.width/2, y2);
        
    }];
    
}

-(void)closePickerView
{
    if (self.cancelHandler) {
        self.cancelHandler();
    }
    float y = WINDOW_Height+self.frame.size.height/2;
    [UIView animateWithDuration:0.2 animations:^{
        self.center = CGPointMake(self.frame.size.width/2, y);
    }completion:^(BOOL finished) {
        
        
    }];
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
