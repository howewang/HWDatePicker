//
//  ViewController.m
//  pickerTEst
//
//  Created by Howe on 2017/6/16.
//  Copyright © 2017年 Howe. All rights reserved.
//

#import "ViewController.h"
#import "HWDatePicker.h"

@interface ViewController ()
//@property (strong , nonatomic) HWDatePicker *picker;
@property (strong , nonatomic) HWDatePicker *picker;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.picker = [[HWDatePicker alloc]initWithPikcerMode:HWDatePickerAllIn scrollHandlder:^(HWDatePickerScrollComponent scrollCompent, NSString *compentValue) {
        
    } doneHandler:^(NSDate *date, NSString *dataString, NSString *dataFormat) {
        NSLog(@"%@",dataString);
    } cancelHandler:^{
        
    }];
    self.picker.minDateString = @"1999-2-4 13:44:59";
    self.picker.maxDateString = @"2019-8-9 14:45:00";
    self.picker.defineShowDate = [NSDate date];
    [self.view addSubview:self.picker];

    
 
    // Do any additional setup after loading the view, typically from a nib.
}
- (IBAction)button:(id)sender {
    [self.picker showPickerView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
