//
//  AppDelegate.h
//  pickerTEst
//
//  Created by Howe on 2017/6/16.
//  Copyright © 2017年 Howe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

