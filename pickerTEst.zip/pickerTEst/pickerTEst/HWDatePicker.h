//
//  HWDatePicker.h
//  pickerTEst
//
//  Created by Howe on 2017/6/16.
//  Copyright © 2017年 Howe. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger,HWDatePickerMode) {

    HWDatePickerNoSecond ,
    HWDatePickerAllIn
};

typedef NS_ENUM(NSInteger,HWDatePickerScrollComponent) {
    HWDatePickerComponentYear = 0,
    HWDatePickerComponentMonth,
    HWDatePickerComponentDay,
    HWDatePickerComponentHour,
    HWDatePickerComponentMinute,
    HWDatePickerComponentSecond
};


@interface HWDatePicker : UIControl

- (instancetype)initWithPikcerMode:(HWDatePickerMode)pickerMode
                    scrollHandlder:(void (^)(HWDatePickerScrollComponent scrollCompent, NSString * compentValue))scrollHandler
                       doneHandler:(void (^)(NSDate *date, NSString *dataString, NSString *dataFormat))doneHandler
                     cancelHandler:(void (^)())cancelHandler;


//最小时间
@property (strong , nonatomic) NSDate *minDate;
//最大时间
@property (strong , nonatomic) NSDate *maxDate;
//最小时间，字符串类型  yyyy-MM-dd hh:mm:ss
@property (copy , nonatomic) NSString *minDateString;
//最大时间，字符串类型  yyyy-MM-dd hh:mm:ss
@property (copy , nonatomic) NSString *maxDateString;
//默认展示时间
@property (strong , nonatomic) NSDate *defineShowDate;

//显示pickerView
- (void)showPickerView;
//关闭plickerView
- (void)closePickerView;
@end
